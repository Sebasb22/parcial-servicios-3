//GET

  axios.get('http://192.168.60.3:5000/books')
  .then((res) => console.log(res))
  .catch((err) => console.log(err))

//POST

//  axios.post('http://192.168.60.3:5000/books', {

//      id: 3,
//      author: "Brandon sanderson",
//      title: "Juramentada"

//  })
//  .then((res) => console.log(res))
//  .catch((err) => console.log(err))

//PUT

//  axios.put('http://192.168.60.3:5000/books/2', {

//      author: "George Orwell",
//      title: "1984"

//  })
//  .then((res) => console.log(res))
//  .catch((err) => console.log(err))

//DELETE

 axios.delete('http://192.168.60.3:5000/books/5')
 .then((res) => console.log(res))
 .catch((err) => console.log(err))